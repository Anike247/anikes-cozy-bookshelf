// Firebase config (Anike's Cozy Bookshelf)
export const firebaseConfig = {
  apiKey: "AIzaSyApfiIqRBOlFNxQECYFayBD8XemLaauNuM",
  authDomain: "anikes-cozy-bookshelf.firebaseapp.com",
  projectId: "anikes-cozy-bookshelf",
  storageBucket: "anikes-cozy-bookshelf.firebasestorage.app",
  messagingSenderId: "641362242608",
  appId: "1:641362242608:web:fc62c054de9eeebd4451f5"
};
